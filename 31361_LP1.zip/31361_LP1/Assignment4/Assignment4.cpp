#include<iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <algorithm>

using namespace std;

class Tokenizer {
public:
    Tokenizer() {}

    vector<vector<string>> tokenizeFile( string fname) {
       cout<<"---MACRO DEFINITIONS---"<<endl;
        vector<vector<string>> tokenizedLines;
        ifstream file(fname);
        if(!file)
        {
            cout<<"Error in opening file"<<endl;
        }
        string line;

        while (getline(file, line)) {
            vector<string> tokens;
            stringstream ss(line);
            string token;

            while (ss >> token) {
                cout<<token<<" ";
                tokens.push_back(token);
            }
            cout<<endl;

            tokenizedLines.push_back(tokens);
        }
        cout<<endl;
        cout<<endl;
        return tokenizedLines;
    }
};

class Pass1 {
private:
    vector<string> mnt;
    vector<string> mdt;
    vector<string> kpdt;
    int kpdtPtr = 1;
    int mdtPtr = 1;
    string fname;

public:
    Pass1(const string& filename) : fname(filename) {}

    void processMacro(const vector<vector<string>>& instructions) {
        vector<string> pnt;

        // PROCESS MNT ENTRY
        string mntEntry = instructions[1][0] + " ";
        int ppCount = 0;
        int kpCount = 0;

        for (size_t i = 1; i < instructions[1].size(); ++i) {
            if (instructions[1][i].find('=') == string::npos) {
                ppCount++;
            } else {
                kpCount++;
            }
        }

        mntEntry += to_string(ppCount) + " ";
        mntEntry += to_string(kpCount) + " ";
        mntEntry += to_string(kpdtPtr) + " ";
        mntEntry += to_string(mdtPtr) + " ";
        mnt.push_back(mntEntry);

        // PROCESS KPDT ENTRY
        for (size_t i = 1; i < instructions[1].size(); ++i) {
            if (instructions[1][i].find('=') != string::npos) {
                string kptEntry;
                string name = instructions[1][i].substr(0, instructions[1][i].find('='));
                string val = instructions[1][i].substr(instructions[1][i].find('=') + 1);
                if (!val.empty()) {
                    kptEntry = name + " " + val;
                } else {
                    kptEntry = name + " -1";
                }
                kpdt.push_back(kptEntry);
                kpdtPtr++;
            }
        }

        // PROCESS PNT ENTRY
        for (size_t i = 1; i < instructions[1].size(); ++i) {
            if (instructions[1][i].find('&') != string::npos) {
                if (instructions[1][i].find('=') != string::npos) {
                string name = instructions[1][i].substr(0, instructions[1][i].find('='));
                pnt.push_back(name);}
                else {
                    string name = instructions[1][i].substr(instructions[1][i].find('&'));
                pnt.push_back(name);}
            }
        }

        // PROCESS MDT ENTRY
        for (size_t i = 2; i < instructions.size(); ++i) {
            string mdtEntry;
            for (size_t j = 0; j < instructions[i].size(); ++j) {
                if (instructions[i][j].find('&') != string::npos) {
                    mdtEntry += "(P," + to_string(find(pnt.begin(), pnt.end(), instructions[i][j]) - pnt.begin()) + ") ";
                } else {
                    mdtEntry += instructions[i][j] + " ";
                }
            }
            mdt.push_back(mdtEntry);
            mdtPtr++;
        }

        cout<<"---PNT---"<<endl;
        vector<string> ::iterator lt=pnt.begin();
        int  count=0;
        while(lt!=pnt.end())
        {
            cout<<count<<" "<<*lt<<endl;
            lt++;
            count++;
        }
        cout<<endl;
    }

    void performPass1() {
        
        Tokenizer tknz;
        fstream macrofile;
        fstream outputFile;
        outputFile.open("OutputFile.txt");
        macrofile.open("MacroFile.txt");
       
        fstream inputFile;
        inputFile.open(fname);
        if(!inputFile)
        {
            cout<<"Error in opening file"<<endl;
        }
        vector<string> input;
        string line;
        cout<<"---INPUT FILE CODE---"<<endl;
        while (getline(inputFile, line)) {
            input.push_back(line);
            cout<<line<<endl;
        }
        string singleline;
        vector<string> ::iterator it=input.begin();
        while(it!=input.end())
        {
            if(*it=="MACRO")
            {
                while(*it!="MEND" && it!=input.end())
                {
                    singleline=*it;
                    macrofile<<*it<<endl;
                    it++;
                }
                macrofile<<*it<<endl;
            }
            else{
                outputFile<<*it<<endl;
            }
            it++;
        }
        outputFile.close();

        fstream output;
        output.open("OutputFile.txt");
        
        cout<<"---OUTPUT FILE CODE---"<<endl;
        while (getline(output, line)) {
            cout<<line<<endl;
        }

        vector<vector<string>> instructions = tknz.tokenizeFile("MacroFile.txt");


        while (true) {
            auto itMacro = find_if(instructions.begin(), instructions.end(),
                [](const vector<string>& line) { return line.size() > 0 && line[0] == "MACRO"; });

            if (itMacro == instructions.end()) break;

            auto itMend = find_if(itMacro, instructions.end(),
                [](const vector<string>& line) { return line.size() > 0 && line[0] == "MEND"; });

            vector<vector<string>> temp(itMacro, itMend + 1);
            instructions.erase(instructions.begin(), itMend + 1);
            processMacro(temp);
        }

        cout<<"---MNT---"<<endl;
        cout<<"pp kp kpdtp mdtp"<<endl;
        vector<string> ::iterator iit=mnt.begin();
        int count=1;
        while(iit!=mnt.end())
        {
           cout<<count<<" "<<*iit<<endl;
            iit++;
            count++;
        }
        cout<<endl;
        cout<<"---MDT---"<<endl;
        vector<string> ::iterator jt=mdt.begin();
        count=1;
        while(jt!=mdt.end())
        {
           cout<<count<<" "<<*jt<<endl;
            jt++;
            count++;
        }
        cout<<endl;
        cout<<"---KPDT---"<<endl;
        vector<string> ::iterator kt=kpdt.begin();
         count=1;
        while(kt!=kpdt.end())
        {
            cout<<count<<" "<<*kt<<endl;
            kt++;
            count++;
        }
        cout<<endl;
       
        cout<<endl;
        cout<<"Finish"<<endl;

        writeToFile("mnt.txt", mnt);
        writeToFile("mdt.txt", mdt);
        writeToFile("kpdt.txt", kpdt);
    }

    void writeToFile(const string& fname, const vector<string>& data) {
        ofstream outFile(fname);
        for (const string& line : data) {
            outFile << line << endl;
        }
    }
};

int main() {
    Pass1 pass1("tc1.txt");
    pass1.performPass1();
    return 0;
}
