// #include<iostream>
// #include<fstream>
// #include<map>
// #include<string>
// #include<vector>
// #include<sstream>

// using namespace std;

// class RI {
//     string input;
//     fstream input_file;
//     fstream literal_file;
//     fstream literal_file1;
//     fstream symbol_file;
//     fstream output_file; 
//     int error = 0;
//     int lc = 0;

// public:
//     map<string, string> mp;
//     map<string, string> reg_map; 
//     map<string, int> symbol;
//     map<string, int> literal;

//     RI(string input) {
//         this->input = input;
//         initializeMaps();
//     }

//     void initializeMaps() {
//         mp["stop"] = "(IS,00)";
//         mp["add"] = "(IS,01)";
//         mp["sub"] = "(IS,02)";
//         mp["mult"] = "(IS,03)";
//         mp["mover"] = "(IS,04)";
//         mp["movem"] = "(IS,05)";
//         mp["comp"] = "(IS,06)";
//         mp["bc"] = "(IS,07)";
//         mp["div"] = "(IS,08)";
//         mp["read"] = "(IS,09)";
//         mp["print"] = "(IS,10)";
//         mp["start"] = "(AD,01)";
//         mp["end"] = "(AD,02)";
//         mp["origin"] = "(AD,03)";
//         mp["equ"] = "(AD,04)";
//         mp["ltorg"] = "(AD,05)";
//         mp["dc"] = "(DL,01)";
//         mp["ds"] = "(DL,02)";

//         reg_map["areg"] = "1";
//         reg_map["breg"] = "2";
//         reg_map["creg"] = "3";
//         reg_map["dreg"] = "4";
//     }

//     int present(string l, map<string, int>& a) {
//         auto it = a.find(l);
//         if (it != a.end()) {
//             return it->second;
//         }
//         return 0;
//     }

//     void processLineWithDirective(const vector<string>& tokens) {
//         if (tokens[0] == "start" && tokens.size() > 1) {
//             lc = stoi(tokens[1]);
//             logOutput(mp[tokens[0]] + "(C," + tokens[1] + ")");
//         } else if (tokens[0] == "dc") {
//             handleDC(tokens);
//         } else if (tokens[0] == "ds") {
//             handleDS(tokens);
//         } else if (tokens[0] == "end" || tokens[0] == "ltorg") {
//             handleEndOrLtorg(tokens[0]);
//         } else {
//             outputInstruction(tokens);
//         }
//     }

//     void handleDC(const vector<string>& tokens) {
//         int symcount = 0;
//         string output = to_string(lc) + " " + mp[tokens[0]] + "(C," + tokens[1] + ")";
//         logOutput(output);
//         if (!present(tokens[1], symbol)) {
//             symbol[tokens[1]] = ++symcount;
//             symbol_file << symcount << " " << tokens[1] << " " << lc << endl;
//         }
//     }

//     void handleDS(const vector<string>& tokens) {
//         string output = to_string(lc) + " " + mp[tokens[0]] + "(C," + tokens[1] + ")";
//         logOutput(output);
//         lc += stoi(tokens[1]);
//         lc--;
//     }

//     void handleEndOrLtorg(const string& directive) {
//         if (directive == "end") {
//             logOutput(to_string(lc) + " " + mp[directive]);
//             return;
//         }
//         string io;
//         vector<string> lines;

//         literal_file.seekg(0, ios::beg);
//         while (getline(literal_file, io)) {
//             io += " " + to_string(lc);
//             lc++;
//             lines.push_back(io);
//         }
//         literal_file1.seekg(0, ios::beg);
//         for (const string& line : lines) {
//             literal_file1 << line << endl;
//         }
//     }

//     void outputInstruction(const vector<string>& tokens) {
//         string output = to_string(lc) + " " + mp[tokens[0]];
//         for (size_t i = 1; i < tokens.size(); i++) {
//             output += outputOperand(tokens[i]);
//         }
//         logOutput(output);
//     }

//     string outputOperand(const string& operand) {
//         if (reg_map.find(operand) != reg_map.end()) {
//             return "(" + reg_map[operand] + ") ";
//         } else if (isdigit(operand[0])) {
//             int temp = handleLiteral(operand);
//             return "(L," + to_string(temp) + ") ";
//         } else {
//             int temp = handleSymbol(operand);
//             return "(S," + to_string(temp) + ") ";
//         }
//     }

//     int handleLiteral(const string& literalStr) {
//         int literalcount = 0;
//         int temp;
//         if (present(literalStr, literal)) {
//             temp = present(literalStr, literal);
//         } else {
//             literalcount++;
//             temp = literalcount;
//             literal[literalStr] = literalcount;
//             literal_file << literalcount << " " << literalStr << endl;
//         }
//         return temp;
//     }

//     int handleSymbol(const string& symbolStr) {
//         int symcount = 0;
//         int temp;
//         if (present(symbolStr, symbol)) {
//             temp = present(symbolStr, symbol);
//         } else {
//             symcount++;
//             temp = symcount;
//             symbol[symbolStr] = symcount;
//             symbol_file << symcount << " " << symbolStr << endl;
//         }
//         return temp;
//     }

//     void processLineWithLabel(const vector<string>& tokens) {
//         int temp;
//         int symcount = 0;
//         if (present(tokens[0], symbol)) {
//             temp = present(tokens[0], symbol);
//             symbol[tokens[0]] = temp;
//             symbol_file << temp << " " << tokens[0] << " " << lc << endl;
//         } else {
//             symbol[tokens[0]] = ++symcount;
//             symbol_file << symcount << " " << tokens[0] << " " << lc << endl;
//         }
//         string output = to_string(lc) + " " + mp[tokens[1]];
//         for (size_t i = 2; i < tokens.size(); i++) {
//             output += outputOperand(tokens[i]);
//         }
//         logOutput(output);
//     }

//     void process() {
//         input_file.open("input_file.txt");
//         literal_file.open("litral_file.txt");
//         literal_file1.open("literal_file1.txt");
//         symbol_file.open("symbol_file.txt");
//         output_file.open("output_file.txt",ios::out); // Open output file

//         if (!input_file) {
//             cout << "Error in opening input file" << endl;
//             return;
//         }

//         if (!output_file) {
//             cout << "Error in opening output file" << endl;
//             return;
//         }

//         string line;
//         while (getline(input_file, line)) {
//             vector<string> tokens = tokenize(line);
//             if (tokens.empty()) continue;

//             if (isDirectiveOrInstruction(tokens)) {
//                 processLineWithDirective(tokens);
//             } else if (isLabel(tokens)) {
//                 processLineWithLabel(tokens);
//             } else {
//                 cout << "Invalid Error:" << endl;
//                 error = 1;
//                 break;
//             }
//             lc++;
//         }

//         closeFiles();
//     }

//     vector<string> tokenize(const string& line) {
//         vector<string> tokens;
//         stringstream check1(line);
//         string intermediate;
//         while (getline(check1, intermediate, ' ')) {
//             tokens.push_back(intermediate);
//         }
//         return tokens;
//     }

//     bool isDirectiveOrInstruction(const vector<string>& tokens) {
//         return mp.find(tokens[0]) != mp.end() || (tokens.size() > 1 && mp.find(tokens[1]) != mp.end());
//     }

//     bool isLabel(const vector<string>& tokens) {
//         return tokens.size() > 1 && mp.find(tokens[1]) != mp.end();
//     }

//     void logOutput(const string& output) {
//         cout << output << endl;  
//         output_file << output << endl; 
//     }

//     void closeFiles() {
//         literal_file.close();
//         input_file.close();
//         symbol_file.close();
//         output_file.close();  
//     }
// };

// int main() {
//     string input;
//     cout << "Enter the string: " << endl;

//     getline(cin, input);
//     RI obj1(input);
//     obj1.process();
//     cout << endl << "FINISH" << endl;
//     return 0;
// }































// #include<iostream>
// #include<fstream>
// #include<map>
// #include<string>
// #include<vector>
// #include<sstream>

// using namespace std;

// class RI {
//     string input;
//     fstream input_file;
//     fstream literal_file;
//     fstream literal_file1;
//     fstream symbol_file;
//     fstream output_file; 
//     int error = 0;
//     int lc = 0;

// public:
//     map<string, string> mp;
//     map<string, string> reg_map; 
//     map<string, int> symbol;
//     map<string, int> temp_symbol;  // Temporary map for symbols without addresses
//     map<string, int> literal;

//     RI(string input) {
//         this->input = input;
//         initializeMaps();
//     }

//     void initializeMaps() {
//         mp["stop"] = "(IS,00)";
//         mp["add"] = "(IS,01)";
//         mp["sub"] = "(IS,02)";
//         mp["mult"] = "(IS,03)";
//         mp["mover"] = "(IS,04)";
//         mp["movem"] = "(IS,05)";
//         mp["comp"] = "(IS,06)";
//         mp["bc"] = "(IS,07)";
//         mp["div"] = "(IS,08)";
//         mp["read"] = "(IS,09)";
//         mp["print"] = "(IS,10)";
//         mp["start"] = "(AD,01)";
//         mp["end"] = "(AD,02)";
//         mp["origin"] = "(AD,03)";
//         mp["equ"] = "(AD,04)";
//         mp["ltorg"] = "(AD,05)";
//         mp["dc"] = "(DL,01)";
//         mp["ds"] = "(DL,02)";

//         reg_map["areg"] = "1";
//         reg_map["breg"] = "2";
//         reg_map["creg"] = "3";
//         reg_map["dreg"] = "4";
//     }

//     int present(const string& l, map<string, int>& a) {
//         auto it = a.find(l);
//         if (it != a.end()) {
//             return it->second;
//         }
//         return 0;
//     }

//     void processLineWithDirective(const vector<string>& tokens) {
//         if (tokens[0] == "start" && tokens.size() > 1) {
//             lc = stoi(tokens[1]);
//             logOutput(mp[tokens[0]] + "(C," + tokens[1] + ")");
//         } else if (tokens[0] == "dc") {
//             handleDC(tokens);
//         } else if (tokens[0] == "ds") {
//             handleDS(tokens);
//         } else if (tokens[0] == "end" || tokens[0] == "ltorg") {
//             handleEndOrLtorg(tokens[0]);
//         } else {
//             outputInstruction(tokens);
//         }
//     }

//     void handleDC(const vector<string>& tokens) {
//         string output = to_string(lc) + " " + mp[tokens[0]] + "(C," + tokens[1] + ")";
//         logOutput(output);
//         if (temp_symbol.find(tokens[1]) != temp_symbol.end()) {
//             symbol[tokens[1]] = lc;
//             temp_symbol.erase(tokens[1]);
//             symbol_file << symbol[tokens[1]] << " " << tokens[1] << " " << lc << endl;
//         } else if (!present(tokens[1], symbol)) {
//             symbol[tokens[1]] = lc;
//             symbol_file << symbol[tokens[1]] << " " << tokens[1] << " " << lc << endl;
//         }
//     }

//     void handleDS(const vector<string>& tokens) {
//         string output = to_string(lc) + " " + mp[tokens[0]] + "(C," + tokens[1] + ")";
//         logOutput(output);
//         lc += stoi(tokens[1]);
//         lc--;
//     }

//     void handleEndOrLtorg(const string& directive) {
//         if (directive == "end") {
//             logOutput(to_string(lc) + " " + mp[directive]);
//             return;
//         }
//         string io;
//         vector<string> lines;

//         literal_file.seekg(0, ios::beg);
//         while (getline(literal_file, io)) {
//             io += " " + to_string(lc);
//             lc++;
//             lines.push_back(io);
//         }
//         literal_file1.seekg(0, ios::beg);
//         for (const string& line : lines) {
//             literal_file1 << line << endl;
//         }
//     }

//     void outputInstruction(const vector<string>& tokens) {
//         string output = to_string(lc) + " " + mp[tokens[0]];
//         for (size_t i = 1; i < tokens.size(); i++) {
//             output += outputOperand(tokens[i]);
//         }
//         logOutput(output);
//     }

//     string outputOperand(const string& operand) {
//         if (reg_map.find(operand) != reg_map.end()) {
//             return "(" + reg_map[operand] + ") ";
//         } else if (isdigit(operand[0])) {
//             int temp = handleLiteral(operand);
//             return "(L," + to_string(temp) + ") ";
//         } else {
//             int temp = handleSymbol(operand);
//             return "(S," + to_string(temp) + ") ";
//         }
//     }

//     int handleLiteral(const string& literalStr) {
//         int literalcount = 0;
//         int temp;
//         if (present(literalStr, literal)) {
//             temp = present(literalStr, literal);
//         } else {
//             literalcount++;
//             temp = literalcount;
//             literal[literalStr] = literalcount;
//             literal_file << literalcount << " " << literalStr << endl;
//         }
//         return temp;
//     }

//     int handleSymbol(const string& symbolStr) {
//         int symcount = 0;
//         int temp;
//         if (present(symbolStr, symbol)) {
//             temp = present(symbolStr, symbol);
//         } else if (temp_symbol.find(symbolStr) != temp_symbol.end()) {
//             // If symbol is in temp_symbol, use that value and remove from temp_symbol
//             temp = temp_symbol[symbolStr];
//             symbol[symbolStr] = temp;
//             temp_symbol.erase(symbolStr);
//             symbol_file << symbol[symbolStr] << " " << symbolStr << " " << lc << endl;
//         } else {
//             // Add to temp_symbol if not already present
//             symcount++;
//             temp = symcount;
//             temp_symbol[symbolStr] = symcount;
//         }
//         return temp;
//     }

//     void processLineWithLabel(const vector<string>& tokens) {
//         int temp;
//         if (symbol.find(tokens[0]) != symbol.end()) {
//             // Symbol already has an address, update it
//             symbol[tokens[0]] = lc;
//             symbol_file << symbol[tokens[0]] << " " << tokens[0] << " " << lc << endl;
//         } else if (temp_symbol.find(tokens[0]) != temp_symbol.end()) {
//             // Symbol was previously encountered without an address, now assign it one
//             symbol[tokens[0]] = lc;
//             temp_symbol.erase(tokens[0]);  // Remove from temp_symbol as it now has an address
//             symbol_file << symbol[tokens[0]] << " " << tokens[0] << " " << lc << endl;
//         } else {
//             // New symbol encountered, add it to temp_symbol
//             symbol_file << symbol[tokens[0]] << " " << tokens[0] << endl;
//             temp_symbol[tokens[0]] = lc;
//         }

//         string output = to_string(lc) + " " + mp[tokens[1]];
//         for (size_t i = 2; i < tokens.size(); i++) {
//             output += outputOperand(tokens[i]);
//         }
//         logOutput(output);
//     }

//     void process() {
//         input_file.open("input_file.txt");
//         literal_file.open("literal_file.txt");
//         literal_file1.open("literal_file1.txt");
//         symbol_file.open("symbol_file.txt");
//         output_file.open("output_file.txt", ios::out); // Open output file

//         if (!input_file) {
//             cout << "Error in opening input file" << endl;
//             return;
//         }

//         if (!symbol_file) {
//             cout << "Error in opening input file" << endl;
//             return;
//         }

//         if (!output_file) {
//             cout << "Error in opening output file" << endl;
//             return;
//         }

//         string line;
//         while (getline(input_file, line)) {
//             vector<string> tokens = tokenize(line);
//             if (tokens.empty()) continue;

//             if (isDirectiveOrInstruction(tokens)) {
//                 processLineWithDirective(tokens);
//             } else if (isLabel(tokens)) {
//                 processLineWithLabel(tokens);
//             } else {
//                 cout << "Invalid Error:" << endl;
//                 error = 1;
//                 break;
//             }
//             lc++;
//         }

//         closeFiles();
//     }

//     vector<string> tokenize(const string& line) {
//         vector<string> tokens;
//         stringstream check1(line);
//         string intermediate;
//         while (getline(check1, intermediate, ' ')) {
//             tokens.push_back(intermediate);
//         }
//         return tokens;
//     }

//     bool isDirectiveOrInstruction(const vector<string>& tokens) {
//         return mp.find(tokens[0]) != mp.end() || (tokens.size() > 1 && mp.find(tokens[1]) != mp.end());
//     }

//     bool isLabel(const vector<string>& tokens) {
//         return tokens.size() > 1 && mp.find(tokens[1]) != mp.end();
//     }

//     void logOutput(const string& output) {
//         cout << output << endl;  
//         output_file << output << endl; 
//     }

//     void closeFiles() {
//         literal_file.close();
//         literal_file1.close();
//         input_file.close();
//         symbol_file.close();
//         output_file.close();  
//     }
// };

// int main() {
//     string input;
//     cout << "Enter the string: " << endl;

//     getline(cin, input);
//     RI obj1(input);
//     obj1.process();
//     cout << endl << "FINISH" << endl;
//     return 0;
// }



#include <bits/stdc++.h>
using namespace std;

class OpcodeTable {
public:
    map<string, pair<string, int>> lookup = {
        {"STOP", {"IS", 0}},
        {"ADD", {"IS", 1}},
        {"SUB", {"IS", 2}},
        {"MULT", {"IS", 3}},
        {"MOVER", {"IS", 4}},
        {"MOVEM", {"IS", 5}},
        {"COMP", {"IS", 6}},
        {"BC", {"IS", 7}},
        {"DIV", {"IS", 8}},
        {"READ", {"IS", 9}},
        {"PRINT", {"IS", 10}},

        {"START", {"AD", 1}},
        {"END", {"AD", 2}},
        {"ORIGIN", {"AD", 3}},
        {"EQU", {"AD", 4}},
        {"LTORG", {"AD", 5}},

        {"DC", {"DL", 1}},
        {"DS", {"DL", 2}},

        {"AREG", {"RG", 1}},
        {"BREG", {"RG", 2}},
        {"CREG", {"RG", 3}},
        {"DREG", {"RG", 4}},

        {"LT", {"CC", 1}},
        {"EQ", {"CC", 2}},
        {"GT", {"CC", 3}},
        {"GE", {"CC", 4}}
    };

    // Returns the class of the given mnemonic
    string get_class(string mnemonic) {
        return lookup[mnemonic].first;
    }

    // Returns the code of the given mnemonic
    int get_code(string mnemonic) {
        return lookup[mnemonic].second;
    }

    // Checks if the given is a mnemonic
    bool is_mnemonic(string name) {
        return lookup.find(name) != lookup.end();
    }
};

class Instruction {
public:
    string label, mnemonic, op1, op2;

    Instruction(string label = "", string mnemonic = "", string op1 = "", string op2 = "") {
        this->label = label;
        this->mnemonic = mnemonic;
        this->op1 = op1;
        this->op2 = op2;
    }

    bool hasLabel() {
        return !this->label.empty();
    }

    bool hasOp1() {
        return !this->op1.empty();
    }

    bool hasOp2() {
        return !this->op2.empty();
    }
};

class Tokenizer {
public:
    // Returns all tokenized lines of input file
    vector<Instruction> TokenizeAll() {
        vector<Instruction> tokenizedLines;

        // Open file
        ifstream inputFile("source_file.txt");

        // Extract each line and tokenize it
        string line;
        while (getline(inputFile, line)) {
            Instruction i = TokenizeSingle(line);
            tokenizedLines.push_back(i);
        }

        // Close file
        inputFile.close();

        return tokenizedLines;
    }

    // Return single tokenized line
    Instruction TokenizeSingle(string line) {
        OpcodeTable opt;
        Instruction inst;
        vector<string> tokens;
        string token;
        stringstream ss(line);
        while (getline(ss, token, ' ')) {
            tokens.push_back(token);
        }

        // Label is not present
        if (opt.is_mnemonic(tokens[0])) {
            inst.mnemonic = tokens[0];
            if (tokens.size() > 1) {
                inst.op1 = tokens[1];
                if (tokens.size() == 3) {
                    inst.op2 = tokens[2];
                }
            }
        }
        // Label is present
        else if (opt.is_mnemonic(tokens[1])) {
            inst.label = tokens[0];
            inst.mnemonic = tokens[1];
            inst.op1 = tokens[2];
            if (tokens.size() == 4) {
                inst.op2 = tokens[3];
            }
        }

        return inst;
    }
};

class Pass1 {
public:
    Tokenizer tknz;
    vector<Instruction> instSet;
    vector<pair<int, string>> iCode;
    vector<pair<string, int>> symTab;
    vector<pair<string, int>> litTab;
    vector<int> poolTab;

    int lc, stPtr, ltPtr, ptPtr;
    OpcodeTable opt;

    Pass1() {
        this->instSet = tknz.TokenizeAll();
        this->stPtr = 0;
        this->ltPtr = 0;
        this->ptPtr = 0;
        this->lc = 0; // Initialize lc to 0
    }

    // Check if label is present in symTab
    bool isInSymTab(string lbl) {
        for (auto i : this->symTab) {
            if (i.first == lbl) {
                return true;
            }
        }
        return false;
    }

    // Print symTab
    void printSymTab() {
        cout << "Symbol Table:" << endl;
        cout << "Index\tLabel\tAddress" << endl;
        for (int i = 0; i < this->symTab.size(); i++) {
            if(symTab[i].second!=-1)
            cout <<"\t" << this->symTab[i].first << "\t" << this->symTab[i].second << endl;
        }
    }

    // Print litTab
    void printLitTab() {
        cout << "Literal Table:" << endl;
        cout << "Index\tLiteral\tAddress" << endl;
        for (int i = 0; i < litTab.size(); i++) {
            cout << i << "\t" << this->litTab[i].first << "\t" << this->litTab[i].second << endl;
        }
    }

    // Print iCode
    void printICode() {
        cout << "Intermediate Code:" << endl;
        cout << "Address\tInstruction Code" << endl;
        for (auto i : iCode) {
            if (i.first == -1) {
                cout << "       \t" << i.second << endl;
            } else {
            
                cout << "\t" << i.second << endl;
            }
        }
    }
    

    // Perform Pass1
    void performPass1() {
        for (auto inst : this->instSet) {
            string ic = "";

            // Process labels
            if (inst.hasLabel()) {
                if (!isInSymTab(inst.label)) {
                    symTab.push_back({inst.label, lc});
                    stPtr++;
                } else {
                    for (int s = 0; s < symTab.size(); s++) {
                        if (symTab[s].first == inst.label) {
                            symTab[s].second = lc;
                        }
                    }
                }
            }

            // Process mnemonics and opcodes
            string mnemonic = inst.mnemonic;

            if (opt.get_class(mnemonic) == "IS") {
                // Add IC for mnemonic
                ic += "(" + opt.get_class(mnemonic) + "," + to_string(opt.get_code(mnemonic)) + ") ";
                
                // Add IC for op1
                if (inst.hasOp1()) {
                    string op1 = inst.op1;
                    if (opt.get_class(op1) == "RG" || opt.get_class(op1) == "CC") {
                        ic += "(" + opt.get_class(op1) + "," + to_string(opt.get_code(op1)) + ") ";
                    } else {
                        if (!isInSymTab(op1)) {
                            symTab.push_back({op1, -1});
                            ic += "(S," + to_string(stPtr) + ") ";
                            stPtr++;
                        } else {
                            // Find index in symTab and add IC
                            auto it = find_if(symTab.begin(), symTab.end(), [&op1](const pair<string, int>& elem) { return elem.first == op1; });
                            int idx = distance(symTab.begin(), it);
                            ic += "(S," + to_string(idx) + ") ";
                        }
                    }
                }

                // Add IC for op2
                if (inst.hasOp2()) {
                    string op2 = inst.op2;
                    // Check if literal
                    if (op2[0] == '=') {
                        litTab.push_back({op2, -1});
                        ic += "(L," + to_string(ltPtr) + ") ";
                        ltPtr++;
                    } else {
                        if (!isInSymTab(op2)) {
                            symTab.push_back({op2, -1});
                            ic += "(S," + to_string(stPtr) + ") ";
                            stPtr++;
                        } else {
                            // Find index in symTab and add IC
                            auto it = find_if(symTab.begin(), symTab.end(), [&op2](const pair<string, int>& elem) { return elem.first == op2; });
                            int idx = distance(symTab.begin(), it);
                            ic += "(S," + to_string(idx) + ") ";
                        }
                    }
                }
                
                // Increment LC
                this->lc++;
            } else if (mnemonic == "START") {
                ic += "(" + opt.get_class("START") + "," + to_string(opt.get_code("START")) + ") ";
                if (inst.hasOp1()) {
                    lc = stoi(inst.op1);
                    ic += "(C," + inst.op1 + ") ";
                } else {
                    lc = 0;
                }
            } else if (mnemonic == "END") {
                ic += "(" + opt.get_class("END") + "," + to_string(opt.get_code("END")) + ") ";
            } else if (mnemonic == "ORIGIN") {
                ic += "(" + opt.get_class("ORIGIN") + "," + to_string(opt.get_code("ORIGIN")) + ") ";
                string c = inst.op1;
                string oprnd = "", oprt = "";
                vector<string> v;
                for (char i : c) {
                    if (i != '+' && i != '-') {
                        oprnd += i;
                    } else {
                        oprt = i;
                        v.push_back(oprnd);
                        oprnd = "";
                    }
                }
                v.push_back(oprnd);

                int newLc = 0;
                for (auto i : symTab) {
                    if (i.first == v[0]) {
                        newLc = i.second;
                    }
                }
                if (oprt == "+") {
                    newLc += stoi(v[1]);
                } else {
                    newLc -= stoi(v[1]);
                }

                this->lc = newLc;

                // Add IC for op1
                int indx = -1;
                for (int i = 0; i < symTab.size(); i++) {
                    if (symTab[i].first == v[0]) {
                        indx = i;
                        break;
                    }
                }
                ic += "(S," + to_string(indx) + ")" + oprt + v[1];
            } else if (mnemonic == "EQU") {
                ic += "(" + opt.get_class("EQU") + "," + to_string(opt.get_code("EQU")) + ") ";
                string c = inst.op1;
                string oprnd = "", oprt = "";
                vector<string> v;
                for (char i : c) {
                    if (i != '+' && i != '-') {
                        oprnd += i;
                    } else {
                        oprt = i;
                        v.push_back(oprnd);
                        oprnd = "";
                    }
                }
                v.push_back(oprnd);

                int newAddr = 0;
                for (auto i : symTab) {
                    if (i.first == v[0]) {
                        newAddr = i.second;
                    }
                }
                if (oprt == "+") {
                    newAddr += stoi(v[1]);
                } else {
                    newAddr -= stoi(v[1]);
                }

                // Update the label in symTab
                for (int s = 0; s < symTab.size(); s++) {
                    if (symTab[s].first == inst.label) {
                        symTab[s].second = newAddr;
                    }
                }

                // Add IC for op1
                int indx = -1;
                for (int i = 0; i < symTab.size(); i++) {
                    if (symTab[i].first == v[0]) {
                        indx = i;
                        break;
                    }
                }
                ic += "(S," + to_string(indx) + ")" + oprt + v[1];
            } else if (mnemonic == "DS") {
                ic += "(" + opt.get_class("DS") + "," + to_string(opt.get_code("DS")) + ") ";
                for (int s = 0; s < symTab.size(); s++) {
                    if (symTab[s].first == inst.label) {
                        symTab[s].second = lc;
                    }
                }
                ic += "(C," + inst.op1 + ") ";
            } else if (mnemonic == "DC") {
                ic += "(" + opt.get_class("DC") + "," + to_string(opt.get_code("DC")) + ") ";
                for (int s = 0; s < symTab.size(); s++) {
                    if (symTab[s].first == inst.label) {
                        symTab[s].second = lc;
                    }
                }
                ic += "(C," + inst.op1 + ") ";
            } else if (mnemonic == "LTORG") {
                for (int l = ptPtr; l < litTab.size(); l++) {
                    litTab[l].second = this->lc;
                    this->lc++;
                    string lit = litTab[l].first;
                    lit = lit.substr(2, lit.length() - 3);
                    ic += "(DL,01) (C," + lit + ") ";
                    iCode.push_back({lc, ic});
                    ic = "";
                }
                ptPtr++;
            }

            if (!ic.empty()) {
                if (opt.get_class(mnemonic) == "AD") {
                    iCode.push_back({-1, ic});
                } else {
                    iCode.push_back({lc, ic});
                }
                if (mnemonic == "DS") {
                    this->lc = lc + stoi(inst.op1);
                } else if (mnemonic == "DC") {
                    this->lc++;
                }
            }
        }
    }
};

int main() {
    Tokenizer tknz;
    vector<Instruction> insts = tknz.TokenizeAll();
    cout << "Tokenized Instructions:" << endl;
    cout << "Label\tMnemonic\tOp1\tOp2" << endl;
    // for (auto i : insts) {
    //     cout << i.label << "\t" << i.mnemonic << "\t" << i.op1 << "\t" << i.op2 << endl;
    // }
    cout << endl;

    Pass1 p1;
    p1.performPass1();

    p1.printICode();
    cout << endl;

    p1.printLitTab();
    cout << endl;

    p1.printSymTab();
    cout << endl;

    return 0;
}