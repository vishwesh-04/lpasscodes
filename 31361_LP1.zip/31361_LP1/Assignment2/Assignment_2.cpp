#include <iostream>
#include <fstream>
#include <cstring>
#include <map>
#include <vector>
#include <ctype.h>
using namespace std;

int main()
{
    string nums[20];
    int lc=0;
    int count=0;
    string Opcode[19][3]={
    {"STOP","IS","00"},
    {"ADD","IS","01"},
    {"SUB","IS","02"},
    {"MULT","IS","03"},
    {"MOVER","IS","04"},
    {"MOVEM","IS","05"},
    {"COMP","IS","06"},
    {"BC","IS","07"},
    {"DIV","IS","08"},
    {"READ","IS","09"},
    {"PRINT","IS","10"},
    {"START","AD","00"},
    {"END","AD","01"},
    {"ORIGIN","AD","03"},
    {"EQU","AD","04"},
    {"LTORG","AD","05"},
    {"DC","DL","00"},
    {"DS","DL","01"}};
    vector<string> ic;
    string registers[5]={"AREG","BREG","CREG","DREG"};
    map <string,int>symboltable; 
    bool okay=false;
    string filename;
    cout<<"Enter the source code filename:"<<endl;
    cin>>filename;
    fstream object;
    string line;
    object.open(filename);
    if(object)
    {
        cout<<"File opened successfully."<<endl;
        cout<<"Your source code is:"<<endl;
    }
    else
    {
        cout<<"Error in opening file"<<endl;
    }
    while(getline(object,line))
    { 
      cout<<line;
      cout<<endl;
    }
    object.close();
    fstream obj;
    obj.open(filename);
    if(obj)
    {
        cout<<"File opened"<<endl;
    }
    while(!obj.eof())
    {
        okay=false;
        string word;
        obj>>word;
       for(int i=0;i<19;i++)
       {
        if(word==Opcode[i][0])
        {
            okay=true;
            if(Opcode[i][1]=="IS")
            {
                lc++;
            }
            string icentry=Opcode[i][1]+" "+Opcode[i][2];
            ic.push_back(icentry);
            break;
        }
       }
       if(okay==false)
       {
        for(int j=0;j<4;j++)
        {
            if(word==registers[j])
            {
                okay=true;
                break;
            }
        }
       }
       if(okay==false)
       {
        bool is_digit=true;
        int n=0;
        while(n<word.length())
        {
            is_digit=true;
             if(!isdigit(word[n]))
            {
                is_digit=false;
                break;
            }
            n++;
        }
        if(is_digit==true)
        {
            nums[count]=word;
            okay=true;
        }
       }
       if(okay==false)
       {
            symboltable.insert({word,0});
       }
    }
    obj.close();
    cout<<"The symbol table :"<<endl;
    map<string,int>::iterator it=symboltable.begin();
    while(it!=symboltable.end())
    {
        if(it->second==0)
        {
            cout<<it->first<<" "<<"---"<<endl;
        }
        it++;   
    }

    cout<<"Intermediate code :"<<endl;
   vector<string>::iterator i=ic.begin();
   while(i!=ic.end())
   {
    cout<<(*i)<<endl;
    i++;
   }
    cout<<endl;
    cout<<endl;
    return 0;
};