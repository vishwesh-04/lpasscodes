// #include <bits/stdc++.h>
#include<iostream>
#include<fstream>
#include<map>
#include<string>
#include<vector>
#include<sstream>
using namespace std;

class RI {
  string input;
  fstream input_file;
  fstream literal_file;
   fstream literal_file1;
  fstream symbol_file;
  int error = 0;
  int lc = 0;

public:
  map<string, string> mp;
  map<string, string> mp1;
  map<string, string> mp2;
  map<string, int> symbol;
  map<string, int> literal;

  RI(string input) {
    this->input = input;
    mp["STOP"] = "(is, 00)";
    mp["ADD"] = "(is, 01)";
    mp["SUB"] = "(is, 02)";
    mp["MULT"] = "(is, 03)";
    mp["MOVER"] = "(is, 04)";
    mp["MOVEM"] = "(is, 05)";
    mp["COMP"] = "(is, 06)";
    mp["BC"] = "(is, 07)";
    mp["DIV"] = "(is, 08)";
    mp["READ"] = "(is, 09)";
    mp["PRINT"] = "(is, 10)";
    mp["START"] = "(ad, 01)";
    mp["END"] = "(ad, 02)";
    mp["ORIGIN"] = "(ad, 03)";
    mp["EQU"] = "(ad, 04)";
    mp["LTORG"] = "(ad, 05)";
    mp["DC"] = "(dl, 01)";
    mp["DS"] = "(dl, 02)";
    mp1["DC"] = "(dl, 01)";
    mp1["DS"] = "(dl, 02)";
    mp2["AREG"]="(register,01)";
    mp2["BREG"]="(register,02)";
    mp2["CREG"]="(register,03)";
    mp2["DREG"]="(register,04)";
  }

  int present(string l, map<std::string, int> a) {
     auto it = a.find(l);
    if (it != a.end()) {
        return it->second;
    }
    return 0;
  }

  void tokenize() {
    int symcount = 0;
    int literalcount = 0;
    string line1;
    input_file.open("input_file.txt");
    literal_file.open("literal_file.txt");
    literal_file1.open("literal_file1.txt");
    symbol_file.open("symbol_file.txt");
    while (getline(input_file, line1)) {
      vector<string> tokens;
      stringstream check1(line1);
      string intermediate;
      while (getline(check1, intermediate, ' ')) {
        tokens.push_back(intermediate);
      }
      vector<string> ::iterator it=tokens.begin();
      while(it!=tokens.end())
      {
        cout<<*it<<endl;
        it++;
      }
    
      map<string, string>::iterator itr = mp.begin();
      int flag = 0;
      int flag1 = 0;
      while (itr != mp.end()) {
        if (itr->first == tokens[0] || itr->first == tokens[1]) {
          flag = 1;
          if (itr->first == tokens[1]) {
            flag1 = 1;
          }
          break;
        }
        itr++;
      }
      if (flag && flag1==0) {
        if (tokens[0] == "START" && tokens.size() > 1) {
          lc = stoi(tokens[1]);
          lc--;
          cout << "   " << mp[tokens[0]];
        } 
        else if("DC"==tokens[0])
        {
            int temp;
            cout <<lc<< " " << mp[tokens[0]];
            if (present(tokens[1], symbol)) {
          temp = present(tokens[1], symbol);
            symbol[tokens[1]] = temp;
            
            symbol_file << temp << " " << tokens[1] << " " << lc << endl;
        } else {
          symbol[tokens[1]] = ++symcount;
          symbol_file << symcount << " " << tokens[1] << " " << lc << endl;
        }
        }
        else if("DS"==tokens[0])
        {
            cout<<lc << " " << mp[tokens[0]];
            lc+=stoi(tokens[2]);
            lc--;
        }
        else if(tokens[0]=="end" || tokens[0]=="ltorg")
        {
            string io;
            vector<string> lines;
            
            literal_file.seekg(0, std::ios::beg);
            while(getline(literal_file,io))
            {
                
                io+=" ";
                io+=to_string(lc);
                lc++;
                
                lines.push_back(io);
               
                
            }
            literal_file1.seekg(0, std::ios::beg);
            for(int k=0;k<lines.size();k++)
            {
                literal_file1<<lines[k]<<endl;
            }
        }
        else {
          cout << lc << " " << mp[tokens[0]];
        }

        for (int i = 1; i < tokens.size(); i++) {
          if (isdigit(tokens[i][0]) == true) {
          
            int temp;

            if (present(tokens[i], literal)) {
              temp = present(tokens[i], literal);
            }
          
            else 
            {
                literalcount++;
                temp=literalcount;
                literal[tokens[i]] = literalcount;
                literal_file << literalcount << " " << tokens[i] << endl;
            }
            cout << "(L, " << temp << ")"
                 << " ";
          } else {
            int temp;
            
            
            if (present(tokens[i], symbol)) {
              
              temp = present(tokens[i], symbol);
            } else {
               
                symcount++;
                 temp = symcount;
              symbol[tokens[i]] = symcount;
              symbol_file << symcount << " " << tokens[i] << endl;
            }
            cout << "(S, " << temp << ") ";
          }
        }
        cout << endl;
      }

       else if (flag1 == 1) {
        int temp;
        if (present(tokens[0], symbol)) {
          temp = present(tokens[0], symbol);
           
            symbol[tokens[0]] = temp;
            symbol_file << temp << " " << tokens[0] << " " << lc << endl;
        } else {
       
          symbol[tokens[0]] = ++symcount;
          symbol_file << symcount << " " << tokens[0] << " " << lc << endl;
        }
        cout << lc << " " << mp[tokens[0]];

        for (int i = 2; i < tokens.size(); i++) {
          if (isdigit(tokens[i][0]) == true) {
            
            int temp = literalcount;

            if (present(tokens[i], literal)) {
              temp = present(tokens[i], literal);
            } else {
              literalcount++;
              literal[tokens[i]] = literalcount;
              literal_file << literalcount << " " << tokens[i] << endl;
            }
            cout << "(L, " << temp << ")"
                 << " ";
          } else {
            int temp;
           
            if (present(tokens[i], symbol)) {
                
              temp = present(tokens[i], symbol);
           
            } else {
                 symcount++;
            temp = symcount;
              symbol[tokens[i]] = symcount;
              symbol_file << symcount << " " << tokens[i] << endl;
            }
            cout << "(S, " << temp << ") ";
          }
        }
        cout << endl;
      } 
    else {
        cout << "Invalid Error:" << endl;
        error = 1;
        break;
      }
      lc++;
    }
    literal_file.close();
    input_file.close();
    symbol_file.close();
  }
};

int main() {
  string input;
  cout << "Enter the string: " << endl;

  getline(cin, input);
  RI obj1(input);
  obj1.tokenize();
  cout << "!!!Hello World!!!" << endl; 
}