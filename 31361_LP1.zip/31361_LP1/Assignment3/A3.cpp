#include<iostream>
#include<vector>
#include<fstream>
using namespace std;

// Function to fetch symbol/literal address from symbol_table or literal_table
string table(ifstream &fin, const string& n)
{
    string no, name, addr;
    while(fin >> no >> name >> addr)
    {
        if(no == n)
        {
            fin.seekg(0, ios::beg);
            return addr;
        }
    }
    fin.seekg(0, ios::beg);
    return "NAN";
}

int main()
{
    ifstream ic("ic1.txt"), st("symtable1.txt"), lt("littable1.txt");
    ofstream mc("machine_code1.txt");

    string lc, ic1, ic2, ic3;
    cout << "\n -- ASSEMBLER PASS-2 OUTPUT --" << endl;
    cout << "\n LC\t <INTERMEDIATE CODE>\t\t\tLC\t <MACHINE CODE>" << endl;

    while(ic >> lc >> ic1 >> ic2 >> ic3) // reading input file line by line
    {
        string MC; // machine code

        // Check that ic1 is long enough before calling substr
        if (ic1.length() >= 4 && (ic1.substr(1, 2) == "AD" || 
            (ic1.substr(1, 2) == "DL" && ic1.length() >= 6 && ic1.substr(4, 2) == "02")))
        {
            MC = " --no machine code-- ";
        }
        else if (ic1.length() >= 6 && ic1.substr(1, 2) == "DL" && ic1.substr(4, 2) == "01")
        {
            // Ensure ic2 is long enough before calling substr
            if (ic2.length() >= 4)
                MC = "00\t0\t00" + ic2.substr(3, 1);
            else
                MC = "Invalid Format";
        }
        else if (ic1.length() >= 6) // IS opcode
        {
            if (ic1.substr(4, 2) == "00") // specifically for STOP
                MC = ic1.substr(4, 2) + "\t0\t000";
            else if (ic2.length() >= 2 && ic2.substr(1, 1) == "S") // if opcode in pass1 was ORIGIN
            {
                MC = ic1.substr(4, 2) + "\t0\t" + table(st, ic2.substr(4, 1));
            }
            else
            {
                if (ic3.length() >= 2 && ic3.substr(1, 1) == "S") // for symbols
                {
                    // if (ic3.length() >= 5)
                    MC = ic1.substr(4, 2) + "\t" + ic2.substr(1, 1) + "\t" + table(st, ic3.substr(4, 1));
                    // else
                    //     MC = "Invalid Format";
                }
                else if (ic3.length() >= 5) // for literals
                {
                    MC = ic1.substr(4, 2) + "\t" + ic2.substr(1, 1) + "\t" + table(lt, ic3.substr(4, 1));
                }
                else
                    MC = "Invalid Format"; // Handle unexpected format
            }
        }
        else
        {
            MC = "Invalid Format";
        }

        // Console output for specific case
        if(ic1 == "(AD,03)") 
        {
            cout << " " << lc << "\t" << ic1 << "\t" << ic2 << " " << ic3 << "\t\t\t" << lc << "\t" << MC << endl;
            mc << lc << "\t" << MC << endl;
            continue;
        }

        // General console output
        cout << " " << lc << "\t" << ic1 << "\t" << ic2 << "\t " << ic3 << "\t\t\t" << lc << "\t" << MC << endl;
        mc << lc << "\t" << MC << endl;
    }

    return 0;
}







