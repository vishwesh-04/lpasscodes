#include <iostream>
#include <fstream>
#include <sstream>
#include <vector>
#include <string>
#include <map>

using namespace std;

class Tokenizer {
public:
    vector<vector<string>> tokenizeFile(const string& fname) {
        vector<vector<string>> tokenizedLines;
        ifstream file(fname);
        string line;

        while (getline(file, line)) {
            vector<string> tokens;
            stringstream ss(line);
            string token;

            while (getline(ss, token, ' ')) {
                tokens.push_back(token);
            }

            tokenizedLines.push_back(tokens);
        }

        return tokenizedLines;
    }
};

class Pass2 {
private:
    vector<vector<string>> mnt;
    vector<vector<string>> mdt;
    map<string, pair<string, string>> kpdt;
    Tokenizer tknz;

    void loadTables() {
        vector<vector<string>> mntEntries = tknz.tokenizeFile("mnt.txt");
        for (const auto& entry : mntEntries) {
            mnt.push_back(entry);
        }

        mdt = tknz.tokenizeFile("mdt.txt");

        vector<vector<string>> kpdtEntries = tknz.tokenizeFile("kpdt.txt");
        for (size_t i = 0; i < kpdtEntries.size(); ++i) {
            string keyword = kpdtEntries[i][0];
            string defaultValue = kpdtEntries[i][1];
            kpdt[to_string(i)] = {keyword,defaultValue};
        }
        
        
         cout << "MNT (Macro Name Table):\n";
        for (const auto& entry : mnt) {
            for (const auto& field : entry) {
                cout << field << " ";
            }
            cout << endl;
        }
        cout<<endl;
        
        cout << "MDT\n";
        for (int i = 0; i < mdt.size(); i++) {
            for (int j = 0; j < mdt[i].size(); j++) {
                cout << mdt[i][j] << " ";
            }
            cout << endl;
        }
        cout << endl;
        
        // cout << "\nKPDT (Keyword Parameter Default Table):\n";
        // for (const auto& [keyword, values] : kpdt) {
        //     cout << "Index: " << keyword << ", Keyword: " << values.first << ", Default value: " << values.second << endl;
        // }
        // cout<<endl;
    }

    int findMacroInMNT(const string& macroName) {
        for (size_t i = 0; i < mnt.size(); ++i) {
            if (mnt[i][0] == macroName) {
                cout<<"index of macro :"<<macroName<<" is:"<<i<<endl;
                return i;
            }
        }
        return -1;
    }
    

    vector<string> getAPT(const vector<string>& call, int macroIndex) {
        vector<string> apt;
        int ppCount = stoi(mnt[macroIndex][1]);
        int kpCount = stoi(mnt[macroIndex][2]);

        // Positional parameters
        for (int i = 1; i <= ppCount; ++i) {
            apt.push_back(call[i]);
        }
 
    // Extract keyword parameters from the call
    map<string, string> kpdtTemp;
    for (int i = ppCount + 1; i < call.size(); ++i) {
        size_t equalPos = call[i].find('=');
        if (equalPos != string::npos) {
            string name = call[i].substr(0, equalPos);
            string value = call[i].substr(equalPos + 1);
            kpdtTemp[name] = value;
            apt.push_back(name+" : "+value);
        }
    }

    // // Ensure all keyword parameters in MNT are included in APT
    // for (int i = 0; i < kpCount; ++i) {
    //     string kpName = mnt[macroIndex][3 + i]; // Fetch keyword parameter names from MNT
    //     // string kpName=kpdt[i]->first;
    //     if (kpName[0] == '&') {
    //         kpName = kpName.substr(1); // Remove the '&' prefix for comparison
    //     }

    //     if (kpdtTemp.find(kpName) != kpdtTemp.end()) {
    //         // If the keyword parameter is provided in the call
    //         apt.push_back(kpdtTemp[kpName]);
    //     } else {
    //         // If not provided, use the default value from KPDT
    //         if (kpdt.find("&" + kpName) != kpdt.end()) {
    //             apt.push_back(kpdt["&" + kpName].first);
    //         } else {
    //             apt.push_back("-1"); // Use a placeholder for missing default values
    //         }
    //     }
    //  }
        return apt;
    }

    // void replace(const vector<string>& apt){
    //     fstream file;
    //    file.open("IC.txt");
    //     for(int i=0;i<mdt.size();i++)
    //    {
    //        file>>apt[mdt[i][2].substr(4,5)];
    //    }

    // }

public:
    void performPass2(const string& sourceFile) {
        loadTables();
        vector<vector<string>> sourceLines = tknz.tokenizeFile(sourceFile);

        for (const auto& line : sourceLines) {
            int macroIndex = findMacroInMNT(line[0]);
            if (macroIndex != -1) { // If it's a macro call
                vector<string> apt = getAPT(line, macroIndex);
                
                // Print the Actual Parameter Table (APT)
                cout << "Actual Parameter Table for macro " << line[0] << ":\n";
                for (const auto& param : apt) {
                    cout << param << " ";
                }
                cout << endl;
            }
        }
    }
};

int main() {
    Pass2 pass2;
    pass2.performPass2("sourcefile.txt");
    return 0;
}



















