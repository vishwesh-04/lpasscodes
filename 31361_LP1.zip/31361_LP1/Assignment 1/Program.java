import java.util.*;

public class Program {
    public static void main(String[] args) {
        Buffer buffer = new Buffer();
        Producer producer = new Producer(buffer);
        Consumer consumer = new Consumer(buffer);

        Thread producerThread = new Thread(producer);
        Thread consumerThread = new Thread(consumer);

        producerThread.start();
        consumerThread.start();
    }
}

class Buffer {
    private int item;
    private boolean hasItem = false;
    private int count = 0;
    private final int BUFFER_SIZE = 10; // Set buffer size

    // Method to produce an item
    synchronized void produce(int item) throws InterruptedException {
        while (count == BUFFER_SIZE) {
            wait(); // Wait if buffer is full
        }
        this.item = item;
        count++;
        System.out.println("Produced: " + item);
        notify(); // Notify consumer that item is produced
    }

    // Method to consume an item
    synchronized void consume(int item) throws InterruptedException {
        while (count == 0) {
            wait(); // Wait if buffer is empty
        }
        int consumedItem = item;
        count--;
        System.out.println("Consumed: " + consumedItem);
        notify(); // Notify producer that item is consumed
    }
}

class Producer implements Runnable {
    private final Buffer buffer;

    Producer(Buffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
                buffer.produce(i);
                Thread.sleep(50); // Simulate time taken to produce an item
            }
        } catch (InterruptedException e) {
            System.out.println("Producer interrupted: " + e);
            Thread.currentThread().interrupt();
        }
    }
}

class Consumer implements Runnable {
    private final Buffer buffer;

    Consumer(Buffer buffer) {
        this.buffer = buffer;
    }

    public void run() {
        try {
            for (int i = 0; i < 10; i++) {
                buffer.consume(i);
                Thread.sleep(200); // Simulate time taken to consume an item
            }
        } catch (InterruptedException e) {
            System.out.println("Consumer interrupted: " + e);
            Thread.currentThread().interrupt();
        }
    }
}

