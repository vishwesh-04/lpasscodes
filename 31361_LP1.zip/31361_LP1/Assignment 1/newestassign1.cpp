//============================================================================
// Name        : Scheduling1.cpp
// Author      : Nidhi Dasari
// Version     :
// Copyright   : Your copyright notice
// Description : Scheduling Algorithms in C++, Ansi-style
//============================================================================

#include <iostream>
#include <string>
#include <algorithm>
#include <vector>
using namespace std;

class Task {
public:
    std::string name;
    int at, bt, wt, ct, ts, tat, rt, pt;

    Task() {
        name = "0";
        at = 0;
        bt = 0;
        wt = 0;
        ct = 0;
        ts = at;
        tat = 0;
        rt = 0;
        pt = 0;
    }

    Task(string name, int at, int bt, int pt = 0) {
        this->name = name;
        this->at = at;
        this->bt = bt;
        this->pt = pt;
        wt = 0;
        ct = 0;
        ts = at;
        tat = 0;
        rt = bt;
    }
};

class Scheduler {
protected:
    vector<Task> tasks;
    int n;

public:
    void input() {
        cout << "Enter the number of tasks to be performed: ";
        cin >> n;
        tasks.resize(n);
        for (int i = 0; i < n; ++i) {
            cout << "Name of task: ";
            cin >> tasks[i].name;
            cout << "Enter arrival time: ";
            cin >> tasks[i].at;
            cout << "Enter burst time: ";
            cin >> tasks[i].bt;
            cout << "Enter priority (0 if not applicable): ";
            cin >> tasks[i].pt;
            tasks[i].rt = tasks[i].bt;
        }
    }

    virtual void process() = 0;

    void display() {
        for (const auto& task : tasks) {
            cout << task.name << " " << task.at << " " << task.bt << " " << task.ct << " " << task.wt << " " << task.tat << endl;
        }
    }

    static bool compareArrival(const Task& t1, const Task& t2) {
        return t1.at < t2.at;
    }

    void sortTasksByArrival() {
        sort(tasks.begin(), tasks.end(), compareArrival);
    }
};

class FCFS : public Scheduler {
public:
    void process() override {
        sortTasksByArrival();
        int currentTime = 0;
        for (int i = 0; i < n; ++i) {
            if (currentTime < tasks[i].at) {
                currentTime = tasks[i].at;
            }
            tasks[i].ct = currentTime + tasks[i].bt;
            tasks[i].wt = currentTime - tasks[i].at;
            tasks[i].tat = tasks[i].ct - tasks[i].at;
            currentTime = tasks[i].ct;
        }
    }
};

class SJF : public Scheduler {
public:
    void process() override {
        sortTasksByArrival();
        int currentTime = 0, completed = 0;
        while (completed != n) {
            int idx = -1;
            for (int i = 0; i < n; ++i) {
                if (tasks[i].rt > 0 && tasks[i].at <= currentTime) {
                    if (idx == -1 || tasks[i].bt < tasks[idx].bt) {
                        idx = i;
                    }
                }
            }
            if (idx != -1) {
                tasks[idx].rt = 0;
                currentTime += tasks[idx].bt;
                tasks[idx].ct = currentTime;
                tasks[idx].wt = tasks[idx].ct - tasks[idx].bt - tasks[idx].at;
                tasks[idx].tat = tasks[idx].ct - tasks[idx].at;
                completed++;
            } else {
                currentTime++;
            }
        }
    }
};

class RR : public Scheduler {
    int ts;

public:
    void input() {
        Scheduler::input();
        cout << "Enter time slice: ";
        cin >> ts;
    }

    void process() override {
        sortTasksByArrival();
        int currentTime = 0, completed = 0, idx = 0;
        while (completed != n) {
            bool found = false;
            for (int i = 0; i < n; ++i) {
                if (tasks[i].at <= currentTime && tasks[i].rt > 0) {
                    found = true;
                    if (tasks[i].rt >ts) {
                        currentTime += ts;
                        tasks[i].rt -= ts;
                    } else {
                        currentTime += tasks[i].rt;
                        tasks[i].rt = 0;
                        tasks[i].ct = currentTime;
                        tasks[i].wt = tasks[i].ct - tasks[i].bt - tasks[i].at;
                        tasks[i].tat = tasks[i].ct - tasks[i].at;
                        completed++;
                    }
                }
            }
            if (!found) currentTime++;
        }
    }
};

class Priority : public Scheduler {
public:
    void process() override {
        sortTasksByArrival();
        int currentTime = 0, completed = 0;
        while (completed != n) {
            int idx = -1;
            for (int i = 0; i < n; ++i) {
                if (tasks[i].at <= currentTime && tasks[i].rt > 0) {
                    if (idx == -1 || tasks[i].pt < tasks[idx].pt) {
                        idx = i;
                    }
                }
            }
            if (idx != -1) {
                tasks[idx].rt = 0;
                currentTime += tasks[idx].bt;
                tasks[idx].ct = currentTime;
                tasks[idx].wt = tasks[idx].ct - tasks[idx].bt - tasks[idx].at;
                tasks[idx].tat = tasks[idx].ct - tasks[idx].at;
                completed++;
            } else {
                currentTime++;
            }
        }
    }
};

void showMenu() {
    cout << "Choose a scheduling algorithm:" << endl;
    cout << "1) FCFS" << endl;
    cout << "2) SJF" << endl;
    cout << "3) Round Robin" << endl;
    cout << "4) Priority" << endl;
    cout << "5) Exit" << endl;
}

int main() {
    Scheduler* scheduler = nullptr;
    RR* obj = nullptr;
    int choice;

    while (true) {
        showMenu();
        cin >> choice;

        switch (choice) {
        case 1:
            scheduler = new FCFS();
            break;
        case 2:
            scheduler = new SJF();
            break;
        case 3:
            obj = new RR();
            break;
        case 4:
            scheduler = new Priority();
            break;
        case 5:
            cout << "Exiting..." << endl;
            return 0;
        default:
            cout << "Invalid choice. Please choose again." << endl;
            continue;
        }
        if(choice == 3)
        {
            obj->input();
            obj->process();
            obj->display();
        }
        else
        {
            scheduler->input();
            scheduler->process();
            scheduler->display();
            delete scheduler;
        }
    }

    return 0;
}
