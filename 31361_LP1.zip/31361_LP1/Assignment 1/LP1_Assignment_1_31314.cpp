#include<iostream>
#include<string>
using namespace std;


class Task
{
public:
    string name;
    int arr_time;
    int burst_time;
    int comp_time;
    int priority;
    int tat;
    int wt;
    int tq;
    Task()
    {
        arr_time=0;
        burst_time=0;
        comp_time=0;
        priority=0;
        tq=0;
    }
    Task(string n,int a,int b,bool t)
    {
        if(t==true)
        {
            name=n;
            arr_time=a;
            burst_time=b;
            comp_time=0;
        }
        else
        {
            name=n;
            priority=a;
            burst_time=b;
            comp_time=0;
        }   
    }   
    void calculate(Task obj,bool b)
    {
        if (b==true)
        {
           comp_time=obj.comp_time+burst_time;
            tat=comp_time-arr_time;
            wt=tat-burst_time;
            if(wt<0)
            {
                wt=0;
            }
        }
        else
        {
            comp_time=obj.comp_time+burst_time;
        }

    } 
};


void FCFS(Task array[],int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            if(array[j].arr_time>array[j+1].arr_time)
            {
                Task temp=array[j];
                array[j]=array[j+1];
                array[j+1]=temp;
            }
        }
    }
}


void Priority(Task array[],int n)
{
    for(int i=0;i<n;i++)
    {
        for(int j=0;j<n-i-1;j++)
        {
            if(array[j].priority>array[j+1].priority)
            {
                Task temp=array[j];
                array[j]=array[j+1];
                array[j+1]=temp;
            }
        }
    }
}

void RR(Task array[],int n)
{
    
}


int main()
{
    int ct[50];
    int tat[50];
    int wt[50];
    Task array[50];
    string nam;
    int num,a,b,ch;
    int tq;
   
    while(true)
    {
        cout<<"Menu:"<<endl;
        cout<<"1)First Come First Serve"<<endl;
        cout<<"2)Shortest Job First"<<endl;
        cout<<"3)Priority scheduling"<<endl;
        cout<<"4)Round robin"<<endl;
        cin>>ch;
        if(ch==1)
        {
            cout<<"Enter the number of tasks:"<<endl;
            cin>>num;
            for(int i=0;i<num;i++)
            {
                cout<<"Enter the name of the task:"<<endl;
                cin>>nam;
                cout<<"Enter the arrival time of the task:"<<endl;
                cin>>a;
                cout<<"Enter the burst time of the task:"<<endl;
                cin>>b;
                Task obj(nam,a,b,true);
                array[i]=obj;
            
            }
            
            cout<<"Data entered:"<<endl;
            for(int i=0;i<num;i++)
            {
                cout<<array[i].name<<" ";
            }
            cout<<endl;
            for(int j=0;j<num;j++)
            {
                cout<<array[j].arr_time<<" ";
            }
            cout<<endl;
            for(int k=0;k<num;k++)
            {
                cout<<array[k].burst_time<<" ";
            }
            cout<<endl;
            FCFS(array,num);
            array[0].calculate(array[0],true);
            for(int m=1;m<num;m++)
            {
                array[m].calculate(array[m-1],true);
            }
            cout<<"Scheduled data:"<<endl;
            cout<<"T     a      b       c     ta     w"<<endl;
            for(int i=0;i<num;i++)
            {
                cout<<array[i].name<<"     ";
                cout<<array[i].arr_time<<"     ";
                cout<<array[i].burst_time<<"     ";
                cout<<array[i].comp_time<<"     ";
                cout<<array[i].tat<<"      ";
                cout<<array[i].wt<<"     ";
                cout<<endl;
            }   
        }
        else if(ch==3)
        {
            cout<<"Enter the number of tasks:"<<endl;

            cin>>num;
            for(int i=0;i<num;i++)
            {
                cout<<"Enter the name of the task:"<<endl;
                cin>>nam;
                cout<<"Enter the priority of the task:"<<endl;
                cin>>a;
                cout<<"Enter the burst time of the task:"<<endl;
                cin>>b;
                Task obj(nam,a,b,false);
                array[i]=obj;
            }
            cout<<"Data entered:"<<endl;
            for(int i=0;i<num;i++)
            {
                cout<<array[i].name<<" ";
            }
            cout<<endl;
            for(int j=0;j<num;j++)
            {
                cout<<array[j].priority<<" ";
            }
            cout<<endl;
            for(int k=0;k<num;k++)
            {
                cout<<array[k].burst_time<<" ";
            }
            cout<<endl;
            Priority(array,num);
            array[0].calculate(array[0],false);
            for(int m=1;m<num;m++)
            {
                array[m].calculate(array[m-1],false);
            }
            cout<<"Scheduled data:"<<endl;
            cout<<"T     p      b       c   "<<endl;
            for(int i=0;i<num;i++)
            {
                cout<<array[i].name<<"     ";
                cout<<array[i].priority<<"     ";
                cout<<array[i].burst_time<<"     ";
                cout<<array[i].comp_time<<"     ";
               cout<<endl;
            }   
        }
        else if(ch==4)
        {
            cout<<"Enter the time quantum:"<<endl;
            cin>>tq;
            RR(array,num);
        }
        else if(ch==5)
        {
            break;
        }
    }
    return 0;
}